from cache import Cache
import os, json, time

def test_cache_roundtrip(tmp_path):
    p = tmp_path / "c.sqlite"
    c = Cache(p)
    c.set("k", {"x": 1})
    assert c.get("k", ttl=999)["x"] == 1

def test_cache_expiry(tmp_path):
    p = tmp_path / "c.sqlite"
    c = Cache(p)
    c.set("k", {"x": 1})
    assert c.get("k", ttl=0) is None
