from __future__ import annotations
import argparse, sqlite3, pathlib, csv, sys
from typing import Optional, Iterable, Tuple, List
from datetime import datetime
from tabulate import tabulate

DB_PATH = pathlib.Path(".expenses.sqlite")

SCHEMA = """
CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY,
  ts TEXT NOT NULL,         -- ISO timestamp
  amount REAL NOT NULL,     -- >= 0
  category TEXT NOT NULL,
  note TEXT
);
CREATE INDEX IF NOT EXISTS idx_expenses_ts ON expenses(ts);
CREATE INDEX IF NOT EXISTS idx_expenses_cat ON expenses(category);
"""

def connect():
    con = sqlite3.connect(DB_PATH)
    return con

def init_db() -> None:
    con = connect()
    with con:
        con.executescript(SCHEMA)
    con.close()

def add_expense(amount: float, category: str, note: str = "") -> int:
    if amount < 0:
        raise SystemExit("amount must be >= 0")
    con = connect()
    with con:
        cur = con.execute("INSERT INTO expenses (ts, amount, category, note) VALUES (?,?,?,?)",
                          (datetime.utcnow().isoformat(timespec="seconds"), amount, category, note))
        eid = cur.lastrowid
    con.close()
    return eid

def list_expenses(month: Optional[str]) -> List[tuple]:
    con = connect()
    cur = con.cursor()
    if month:
        # month in YYYY-MM
        start = f"{month}-01T00:00:00"
        # crude next month calc
        y, m = map(int, month.split("-"))
        ny, nm = (y + (m==12), 1 if m==12 else m+1)
        end = f"{ny:04d}-{nm:02d}-01T00:00:00"
        cur.execute("SELECT id, ts, amount, category, note FROM expenses WHERE ts>=? AND ts<? ORDER BY ts DESC", (start, end))
    else:
        cur.execute("SELECT id, ts, amount, category, note FROM expenses ORDER BY ts DESC")
    rows = cur.fetchall()
    con.close()
    return rows

def month_summary(month: str) -> List[tuple]:
    con = connect()
    cur = con.cursor()
    y, m = map(int, month.split("-"))
    start = f"{month}-01T00:00:00"
    ny, nm = (y + (m==12), 1 if m==12 else m+1)
    end = f"{ny:04d}-{nm:02d}-01T00:00:00"
    cur.execute("""
        SELECT category, ROUND(SUM(amount),2) as total, COUNT(*)
        FROM expenses
        WHERE ts>=? AND ts<?
        GROUP BY category
        ORDER BY total DESC
    """, (start, end))
    rows = cur.fetchall()
    con.close()
    return rows

def export_csv(path: str) -> None:
    rows = list_expenses(None)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["id","ts","amount","category","note"])
        w.writerows(rows)

def import_csv(path: str) -> None:
    init_db()
    con = connect()
    with open(path, newline="") as f, con:
        r = csv.DictReader(f)
        for row in r:
            con.execute("INSERT INTO expenses (id, ts, amount, category, note) VALUES (?,?,?,?,?)",
                        (row["id"] or None, row["ts"], float(row["amount"]), row["category"], row.get("note","")))
    con.close()

def plot_month(month: str) -> None:
    import matplotlib.pyplot as plt
    rows = month_summary(month)
    if not rows:
        print("No data for", month)
        return
    cats = [r[0] for r in rows]
    vals = [r[1] for r in rows]
    plt.figure()
    plt.bar(cats, vals)
    plt.title(f"Spending by Category — {month}")
    plt.xlabel("Category"); plt.ylabel("Total")
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.show()

def main() -> None:
    ap = argparse.ArgumentParser(description="Expense Tracker CLI")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init")

    ap_add = sub.add_parser("add")
    ap_add.add_argument("amount", type=float)
    ap_add.add_argument("--cat", dest="category", required=True)
    ap_add.add_argument("--note", default="")

    ap_list = sub.add_parser("list")
    ap_list.add_argument("--month", help="YYYY-MM")

    ap_sum = sub.add_parser("summary")
    ap_sum.add_argument("--month", required=True, help="YYYY-MM")

    ap_export = sub.add_parser("export")
    ap_export.add_argument("path")

    ap_import = sub.add_parser("import")
    ap_import.add_argument("path")

    ap_plot = sub.add_parser("plot")
    ap_plot.add_argument("--month", required=True, help="YYYY-MM")

    args = ap.parse_args()

    if args.cmd == "init":
        init_db()
        print("Initialized DB at", DB_PATH)
    elif args.cmd == "add":
        init_db()
        eid = add_expense(args.amount, args.category, args.note)
        print("Added expense id", eid)
    elif args.cmd == "list":
        rows = list_expenses(args.month)
        print(tabulate(rows, headers=["id","ts","amount","category","note"]))
    elif args.cmd == "summary":
        rows = month_summary(args.month)
        print(tabulate(rows, headers=["category","total","count"]))
    elif args.cmd == "export":
        export_csv(args.path)
        print("Exported to", args.path)
    elif args.cmd == "import":
        import_csv(args.path)
        print("Imported from", args.path)
    elif args.cmd == "plot":
        plot_month(args.month)

if __name__ == "__main__":
    main()
