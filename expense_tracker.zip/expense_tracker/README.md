# Expense Tracker CLI

Command‑line expense tracker with SQLite storage and CSV import/export.
Generates monthly summaries and category reports. Produces charts with matplotlib.

## Features
- Add expense: `python tracker.py add 12.34 --cat groceries --note "milk"`
- List expenses with filters: `python tracker.py list --month 2025-09`
- Summary report: `python tracker.py summary --month 2025-09`
- Export/Import CSV: `python tracker.py export out.csv` / `python tracker.py import in.csv`
- Plot month totals: `python tracker.py plot --month 2025-09`

## Quick start
```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python tracker.py init
python tracker.py add 8.99 --cat coffee --note latte
python tracker.py summary --month 2025-09
```
